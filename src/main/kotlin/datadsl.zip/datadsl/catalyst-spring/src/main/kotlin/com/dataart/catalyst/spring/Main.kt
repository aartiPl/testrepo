package com.dataart.catalyst.spring

fun main() {
    println("Spring")
}
