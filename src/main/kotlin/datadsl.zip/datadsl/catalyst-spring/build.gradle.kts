
dependencies {
    implementation(kotlin("script-runtime"))
}
