rootProject.name = "catalyst"

include("catalyst-aws")
include("catalyst-util")
include("catalyst-database")
include("catalyst-spring")
