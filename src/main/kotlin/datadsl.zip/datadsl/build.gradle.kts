import org.jetbrains.kotlin.gradle.tasks.KotlinCompile

plugins {
    kotlin("jvm") version "1.7.20"
}

buildscript {
    repositories {
        mavenLocal()
        mavenCentral()
    }

    dependencies {
        classpath("com.dataart.gradle:gradle-common:1.0.0-SNAPSHOT")
    }
}

apply(plugin = "com.dataart.gradle-common")

configure<com.dataart.gradle.common.GradlePluginExtension> {
    testCoverage {
        excludeClasses = listOf("*MainKt")
        testLinesCoverage = 100
        testInstructionCoverage = 100
        testBranchCoverage = 100
    }
}

group = "com.dataart.catalyst"
version = "1.0.0-SNAPSHOT"

tasks.withType<KotlinCompile> {
    kotlinOptions.jvmTarget = "1.8"
}

allprojects {
    repositories {
        mavenCentral()
    }
}

subprojects {
    apply(plugin = "org.jetbrains.kotlin.jvm")

    dependencies {
        testImplementation(kotlin("test"))
        testImplementation("com.willowtreeapps.assertk:assertk:0.25")
        testImplementation("org.assertj:assertj-core:3.23.1")
        testImplementation("nl.jqno.equalsverifier:equalsverifier:3.10.1")
    }
    tasks.test {
        useJUnitPlatform()
    }

    tasks.withType<KotlinCompile> {
        kotlinOptions.jvmTarget = "1.8"
    }
}
