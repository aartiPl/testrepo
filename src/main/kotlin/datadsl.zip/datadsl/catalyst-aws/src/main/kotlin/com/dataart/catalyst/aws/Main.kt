package com.dataart.catalyst.aws

fun main() {
    println("AWS")
}
