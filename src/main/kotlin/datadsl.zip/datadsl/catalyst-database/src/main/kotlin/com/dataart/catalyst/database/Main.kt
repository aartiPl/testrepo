package com.dataart.catalyst.database

fun main() {
    println("Database")
}
