package com.dataart.catalyst.util.datadsl.dsl

import com.dataart.catalyst.util.datadsl.visitor.Visitable
import com.dataart.catalyst.util.datadsl.visitor.Visitor

enum class BinaryOperator : Visitable {
    Equals, NotEquals, Less, More, LessOrEquals, MoreOrEquals;

    override fun <T> accept(visitor: Visitor<T>): T = visitor.visit(this)
}
