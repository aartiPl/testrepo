package com.dataart.catalyst.util.marker

import com.dataart.catalyst.util.annotation.OnlyKotlinCode

class TypedMarker<T> private constructor(override val name: String, override val clazz: Class<T>) :
    Marker(name, clazz) {
    companion object {
        @JvmStatic
        fun <T> create(name: String, clazz: Class<T>) = TypedMarker(name, clazz)

        @OnlyKotlinCode
        inline fun <reified T> create(name: String) = create(name, T::class.java)
    }
}
