package com.dataart.catalyst.util.datadsl.visitor

interface Visitable {
    fun <T> accept(visitor: Visitor<T>): T
}
