package com.dataart.catalyst.util.property

import com.dataart.catalyst.util.marker.Marker
import com.dataart.catalyst.util.marker.TypedMarker

@Suppress("UNCHECKED_CAST")
class TypedProperties internal constructor(private val map: Map<Marker, Any?>) :
    Iterable<Map.Entry<Marker, Any?>> {

    fun get(key: Marker): Any? = map[key]

    fun <T> get(marker: TypedMarker<T>): T? = map[marker] as? T

    fun <T> getOrThrow(marker: TypedMarker<T>): T {
        val value = map[marker]

        if (isPropertyKeyMissing(value, marker)) {
            throw NoSuchElementException("Marker $marker is missing in the properties.")
        }

        return value as T
    }

    fun <T> getOrDefault(marker: TypedMarker<T>, defaultValue: T): T {
        val value = map[marker]

        if (isPropertyKeyMissing(value, marker)) {
            return defaultValue
        }

        return value as T
    }

    fun <T> getOrElse(marker: TypedMarker<T>, defaultValue: () -> T): T {
        val value = map[marker]

        if (isPropertyKeyMissing(value, marker)) {
            return defaultValue()
        }

        return value as T
    }

    @get:JvmName("size")
    val size: Int
        get() = map.size

    @get:JvmName("entries")
    val entries: Set<Map.Entry<Marker, Any?>>
        get() = map.entries

    @get:JvmName("keys")
    val keys: Set<Marker>
        get() = map.keys

    @get:JvmName("values")
    val values: Collection<Any?>
        get() = map.values

    fun isEmpty(): Boolean = map.isEmpty()

    fun containsValue(value: Any?): Boolean = map.containsValue(value)

    fun containsKey(key: Marker): Boolean = map.containsKey(key)

    override fun iterator(): Iterator<Map.Entry<Marker, Any?>> = map.iterator()

    private fun isPropertyKeyMissing(any: Any?, marker: Marker) = any == null && !map.containsKey(marker)

    companion object {
        @JvmStatic
        fun builder() = TypedPropertiesBuilder()
    }
}
