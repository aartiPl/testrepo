package com.dataart.catalyst.util.generator

import java.util.concurrent.atomic.AtomicInteger

@Suppress("MemberVisibilityCanBePrivate")
class IntGenerator(val sequenceStart: Int = Int.MIN_VALUE) : Generator<Int> {
    private val counter = AtomicInteger(sequenceStart)

    override fun next(): Int = counter.getAndIncrement()
}
