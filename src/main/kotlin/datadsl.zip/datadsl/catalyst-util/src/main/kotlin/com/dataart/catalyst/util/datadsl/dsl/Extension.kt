package com.dataart.catalyst.util.datadsl.dsl

import com.dataart.catalyst.util.marker.TypedMarker

infix fun <T> TypedMarker<T>.equalsTo(value: T) = BinaryColumnValueExpression(this, BinaryOperator.Equals, value)
infix fun <T> TypedMarker<T>.moreThan(value: T) = BinaryColumnValueExpression(this, BinaryOperator.More, value)
infix fun <T> TypedMarker<T>.moreOrEqualsThan(value: T) =
    BinaryColumnValueExpression(this, BinaryOperator.MoreOrEquals, value)

infix fun <T> TypedMarker<T>.equalsTo(marker: TypedMarker<T>) =
    BinaryColumnExpression(this, BinaryOperator.Equals, marker)

infix fun <T> TypedMarker<T>.moreThan(marker: TypedMarker<T>) =
    BinaryColumnExpression(this, BinaryOperator.More, marker)

infix fun <T> TypedMarker<T>.notEqualsTo(value: T) = BinaryColumnValueExpression(this, BinaryOperator.NotEquals, value)
infix fun <T> TypedMarker<T>.notEqualsTo(column: TypedMarker<T>) =
    BinaryColumnExpression(this, BinaryOperator.NotEquals, column)

infix fun Expression.and(expression: Expression) = BinaryBooleanExpression(this, BinaryBooleanOperator.And, expression)

infix fun Expression.or(expression: Expression) = BinaryBooleanExpression(this, BinaryBooleanOperator.Or, expression)

fun not(expression: Expression) = UnaryBooleanExpression(UnaryBooleanOperator.Not, expression)
