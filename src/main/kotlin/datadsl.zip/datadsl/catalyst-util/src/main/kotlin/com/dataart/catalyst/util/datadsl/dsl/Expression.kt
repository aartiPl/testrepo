package com.dataart.catalyst.util.datadsl.dsl

import com.dataart.catalyst.util.datadsl.visitor.Visitable
import com.dataart.catalyst.util.datadsl.visitor.Visitor

internal object NoExpression : Expression

interface Expression : Visitable {
    override fun <T> accept(visitor: Visitor<T>): T = visitor.visit(this)
}
