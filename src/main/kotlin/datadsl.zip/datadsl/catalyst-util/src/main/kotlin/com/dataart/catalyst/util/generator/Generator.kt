package com.dataart.catalyst.util.generator

interface Generator<T> {
    fun next(): T
}
