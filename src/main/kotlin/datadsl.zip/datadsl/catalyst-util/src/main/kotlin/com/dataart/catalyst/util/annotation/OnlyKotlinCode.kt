package com.dataart.catalyst.util.annotation

annotation class OnlyKotlinCode
