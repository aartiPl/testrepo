package com.dataart.catalyst.util.datadsl.dsl

import com.dataart.catalyst.util.marker.TypedMarker

data class By(val marker: TypedMarker<*>, val order: SortOrder = SortOrder.Ascending)
