package com.dataart.catalyst.util.datadsl.visitor

import com.dataart.catalyst.util.marker.TypedMarker
import com.dataart.catalyst.util.datadsl.dsl.BinaryBooleanExpression
import com.dataart.catalyst.util.datadsl.dsl.BinaryColumnExpression
import com.dataart.catalyst.util.datadsl.dsl.BinaryColumnValueExpression
import com.dataart.catalyst.util.datadsl.dsl.UnaryBooleanExpression
import com.dataart.catalyst.util.datadsl.dsl.*

class SqlGeneratingVisitor : Visitor<String> {
    override fun visit(query: Query): String {
        val sb = StringBuilder()

        sb.append(visit(query.projection))
        sb.append(visit(query.condition))
        sb.append(visit(query.sorter))
        sb.append(visit(query.limiter))

        return sb.toString()
    }

    override fun visit(projection: Projection): String {
        if (projection.columns.isEmpty()) {
            return "SELECT *"
        }

        return "SELECT " + projection.columns.joinToString(", ") { it.name }
    }

    override fun visit(condition: Condition): String {
        if (condition.expression == NoExpression) {
            return ""
        }

        return " WHERE " + visit(condition.expression)
    }

    override fun visit(sorter: Sorter): String {
        if (sorter.byList.isEmpty()) {
            return ""
        }

        return " ORDER BY " + sorter.byList.joinToString(", ") { visit(it.marker) + " " + visit(it.order) }
    }

    override fun visit(limiter: Limiter): String = " LIMIT ${limiter.limit} OFFSET ${limiter.offset}"

    //------------------------------------------------------------------------------------------------------------------

    override fun visit(expression: Expression): String {
        if (expression === NoExpression) {
            return ""
        }

        return expression.accept(this)
    }

    override fun <TYPE> visit(expression: BinaryColumnValueExpression<TYPE>): String =
        visit(expression.marker) + " " + visit(expression.binaryOperator) + " " +
                visitValue(expression.value)

    override fun <TYPE> visit(expression: BinaryColumnExpression<TYPE>): String =
        visit(expression.marker1) + " " + visit(expression.binaryOperator) + " " +
                visit(expression.marker2)

    override fun visit(expression: BinaryBooleanExpression): String =
        visit(expression.operand1) + " " + visit(expression.operator) + " " +
                visit(expression.operand2)

    override fun visit(expression: UnaryBooleanExpression): String =
        visit(expression.operator) + "(" + visit(expression.operand) + ")"

    override fun visit(sortOrder: SortOrder): String = when (sortOrder) {
        SortOrder.Ascending -> "ASC"
        SortOrder.Descending -> "DESC"
    }

    override fun visit(operator: BinaryOperator): String = when (operator) {
        BinaryOperator.Equals -> "=="
        BinaryOperator.NotEquals -> "<>"
        BinaryOperator.Less -> "<"
        BinaryOperator.More -> ">"
        BinaryOperator.LessOrEquals -> "<="
        BinaryOperator.MoreOrEquals -> ">="
    }

    override fun visit(operator: UnaryBooleanOperator): String = when (operator) {
        UnaryBooleanOperator.Not -> "NOT"
    }

    override fun visit(operator: BinaryBooleanOperator): String = when (operator) {
        BinaryBooleanOperator.And -> "AND"
        BinaryBooleanOperator.Or -> "OR"
    }

    override fun <TYPE> visit(marker: TypedMarker<TYPE>): String = marker.name

    override fun <TYPE> visitValue(value: TYPE): String = when(value) {
        is String -> '"' + value + '"'
        else -> value.toString()
    }
}
