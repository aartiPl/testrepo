package com.dataart.catalyst.util.datadsl.dsl

import com.dataart.catalyst.util.marker.Marker
import com.dataart.catalyst.util.datadsl.visitor.Visitable
import com.dataart.catalyst.util.datadsl.visitor.Visitor

data class Projection(val columns: List<Marker>) : Visitable {
    override fun <T> accept(visitor: Visitor<T>): T = visitor.visit(this)

    companion object {
        val default = Projection(emptyList())
    }
}
