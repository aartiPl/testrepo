package com.dataart.catalyst.util.datadsl.dsl

import com.dataart.catalyst.util.marker.Marker

class QueryDsl {
    fun select(vararg markers: Marker): ConditionDsl {
        val queryBuilder = QueryBuilder()
        queryBuilder.projection = Projection(markers.toList())
        return ConditionDsl(queryBuilder)
    }
}
