package com.dataart.catalyst.util.datadsl.dsl

class ConditionDsl(private val queryBuilder: QueryBuilder) {
    fun where(expression: Expression): SorterDsl {
        queryBuilder.condition = Condition(expression)
        return SorterDsl(queryBuilder)
    }

    fun build(): Query = queryBuilder.build()
}
