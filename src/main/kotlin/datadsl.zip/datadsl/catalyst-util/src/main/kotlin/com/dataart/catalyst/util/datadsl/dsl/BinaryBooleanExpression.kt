package com.dataart.catalyst.util.datadsl.dsl

import com.dataart.catalyst.util.datadsl.visitor.Visitable
import com.dataart.catalyst.util.datadsl.visitor.Visitor

data class BinaryBooleanExpression(
    val operand1: Expression,
    val operator: BinaryBooleanOperator,
    val operand2: Expression
) : Expression, Visitable {
    override fun <T> accept(visitor: Visitor<T>): T = visitor.visit(this)
}
