package com.dataart.catalyst.util.datadsl.dsl

class LimiterDsl(private val queryBuilder: QueryBuilder) {
    fun limit(limit: Int, offset: Int = 0): QueryBuilder {
        queryBuilder.limiter = Limiter(limit, offset)
        return queryBuilder
    }

    fun build(): Query = queryBuilder.build()
}
