package com.dataart.catalyst.util.datadsl.generator

import com.dataart.catalyst.util.datadsl.dsl.Statement

interface Generator {
    fun generate(statement: Statement)
}
