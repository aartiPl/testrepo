package com.dataart.catalyst.util.datadsl.dsl

import com.dataart.catalyst.util.datadsl.visitor.Visitable
import com.dataart.catalyst.util.datadsl.visitor.Visitor
import com.dataart.catalyst.util.marker.TypedMarker

data class BinaryColumnExpression<T>(
    val marker1: TypedMarker<T>, val binaryOperator: BinaryOperator, val marker2: TypedMarker<T>
) : Expression, Visitable {
    override fun <T> accept(visitor: Visitor<T>): T = visitor.visit(this)
}
