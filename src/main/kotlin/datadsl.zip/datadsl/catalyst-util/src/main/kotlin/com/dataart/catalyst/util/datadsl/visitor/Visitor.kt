package com.dataart.catalyst.util.datadsl.visitor

import com.dataart.catalyst.util.marker.TypedMarker
import com.dataart.catalyst.util.datadsl.dsl.*

interface Visitor<T> {
    fun visit(query: Query): T
    fun visit(projection: Projection): T
    fun visit(condition: Condition): T
    fun visit(sorter: Sorter): T
    fun visit(limiter: Limiter): T

    fun visit(expression: Expression): T
    fun <TYPE> visit(expression: BinaryColumnValueExpression<TYPE>): T
    fun <TYPE> visit(expression: BinaryColumnExpression<TYPE>): T
    fun visit(expression: BinaryBooleanExpression): T
    fun visit(expression: UnaryBooleanExpression): T
    fun visit(sortOrder: SortOrder): T
    fun visit(operator: BinaryOperator): T
    fun visit(operator: UnaryBooleanOperator): T
    fun visit(operator: BinaryBooleanOperator): T
    fun <TYPE> visit(marker: TypedMarker<TYPE>): T
    fun <TYPE> visitValue(value: TYPE): T
}
