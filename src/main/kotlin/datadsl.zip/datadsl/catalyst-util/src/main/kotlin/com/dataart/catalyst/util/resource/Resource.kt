package com.dataart.catalyst.util.resource

import java.net.URL
import java.util.*

object Resource {
    @JvmStatic
    fun find(resourcePath: String): URL? {
        val loader = Objects.requireNonNullElse(
            Thread.currentThread().contextClassLoader, Resource::class.java.classLoader
        )
        return loader.getResource(resourcePath)
    }

    @JvmStatic
    fun exists(resourcePath: String) = find(resourcePath) != null

    @JvmStatic
    fun asString(resourcePath: String): String {
        return find(resourcePath)?.readText()
            ?: throw IllegalArgumentException("Invalid or non-existing resourcePath '$resourcePath'")
    }
}
