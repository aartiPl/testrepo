package com.dataart.catalyst.util.datadsl.dsl

import com.dataart.catalyst.util.datadsl.visitor.Visitable
import com.dataart.catalyst.util.datadsl.visitor.Visitor

enum class BinaryBooleanOperator : Visitable {
    And, Or;

    override fun <T> accept(visitor: Visitor<T>): T = visitor.visit(this)
}
