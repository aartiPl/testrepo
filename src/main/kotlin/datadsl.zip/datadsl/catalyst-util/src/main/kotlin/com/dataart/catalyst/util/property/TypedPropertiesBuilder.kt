package com.dataart.catalyst.util.property

import com.dataart.catalyst.util.marker.Marker
import com.dataart.catalyst.util.marker.TypedMarker

@Suppress("MemberVisibilityCanBePrivate")
class TypedPropertiesBuilder internal constructor() {
    private val map = mutableMapOf<Marker, Any?>()

    fun <T> addProperty(marker: TypedMarker<T>, value: T) = apply {
        map[marker] = value
    }

    fun build(): TypedProperties {
        return TypedProperties(map)
    }
}
