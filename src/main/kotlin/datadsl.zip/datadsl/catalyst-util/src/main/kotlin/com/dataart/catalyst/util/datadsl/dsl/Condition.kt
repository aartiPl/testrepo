package com.dataart.catalyst.util.datadsl.dsl

data class Condition(val expression: Expression) {
    companion object {
        val default = Condition(NoExpression)
    }
}
