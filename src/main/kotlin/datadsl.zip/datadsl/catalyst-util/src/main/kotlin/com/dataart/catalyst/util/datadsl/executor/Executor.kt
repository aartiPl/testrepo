package com.dataart.catalyst.util.datadsl.executor

import com.dataart.catalyst.util.datadsl.dsl.Statement

interface Executor {
    fun execute(statement: Statement)
}
