package com.dataart.catalyst.util.datadsl.dsl

class QueryBuilder {
    internal var projection: Projection = Projection.default
    internal var condition: Condition = Condition.default
    internal var sorter: Sorter = Sorter.default
    internal var limiter: Limiter = Limiter.default

    fun build(): Query {
        return Query(projection, condition, sorter, limiter)
    }
}
