package com.dataart.catalyst.util.datadsl.dsl

import com.dataart.catalyst.util.datadsl.visitor.Visitable
import com.dataart.catalyst.util.datadsl.visitor.Visitor

data class Query(val projection: Projection, val condition: Condition, val sorter: Sorter, val limiter: Limiter) :
    Statement, Visitable {
    override fun <T> accept(visitor: Visitor<T>): T = visitor.visit(this)

    companion object {
        fun builder() = QueryDsl()
    }
}
