package com.dataart.catalyst.util.marker

@Suppress("UnnecessaryAbstractClass")
abstract class Marker(open val name: String, open val clazz: Class<*>) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as Marker

        if (name != other.name) return false

        return true
    }

    override fun hashCode(): Int {
        return name.hashCode()
    }

    override fun toString(): String {
        return "Marker(name='$name'[, clazz=$clazz])"
    }
}
