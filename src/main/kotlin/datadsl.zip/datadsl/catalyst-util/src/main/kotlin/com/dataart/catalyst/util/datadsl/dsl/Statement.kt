package com.dataart.catalyst.util.datadsl.dsl

interface Statement {
}
