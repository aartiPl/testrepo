package com.dataart.catalyst.util.datadsl.dsl

class SorterDsl(private val queryBuilder: QueryBuilder) {
    fun sort(vararg bys: By): LimiterDsl {
        queryBuilder.sorter = Sorter(bys.toList())
        return LimiterDsl(queryBuilder)
    }

    fun build(): Query = queryBuilder.build()
}
