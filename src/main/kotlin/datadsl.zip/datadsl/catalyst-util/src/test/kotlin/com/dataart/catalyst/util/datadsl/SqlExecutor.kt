package com.dataart.catalyst.util.datadsl

import com.dataart.catalyst.util.datadsl.dsl.Query
import com.dataart.catalyst.util.property.TypedProperties

class SqlExecutor {
    fun execute(query: Query): List<TypedProperties> {
        return listOf(
            TypedProperties.builder()
                .addProperty(name, "Luke Skywalker")
                .addProperty(age, 42)
                .build(),
            TypedProperties.builder()
                .addProperty(name, "Leia Organa")
                .addProperty(age, 35)
                .build(),
            TypedProperties.builder()
                .addProperty(name, "Darth Vader")
                .addProperty(age, 38)
                .build(),
        )
    }
}
