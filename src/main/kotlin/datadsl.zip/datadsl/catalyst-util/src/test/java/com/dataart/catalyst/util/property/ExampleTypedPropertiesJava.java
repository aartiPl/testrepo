package com.dataart.catalyst.util.property;

import com.dataart.catalyst.util.marker.TypedMarker;

@SuppressWarnings("unused")
class ExamplePersonJava {
    private final String name;
    private final String surname;

    ExamplePersonJava(String name, String surname) {
        this.name = name;
        this.surname = surname;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }
}

public class ExampleTypedPropertiesJava {
    static TypedMarker<Integer> timeout = TypedMarker.create("timeout value", Integer.class);
    static TypedMarker<String> name = TypedMarker.create("name", String.class);
    static TypedMarker<String> description = TypedMarker.create("description", String.class);
    static TypedMarker<Double> ratio = TypedMarker.create("request ration before upscaling", Double.class);
    static TypedMarker<ExamplePersonJava> nonExistingPerson = TypedMarker.create("person property", ExamplePersonJava.class);
}
