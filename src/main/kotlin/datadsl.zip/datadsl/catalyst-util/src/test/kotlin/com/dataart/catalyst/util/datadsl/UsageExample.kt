package com.dataart.catalyst.util.datadsl

import com.dataart.catalyst.util.marker.TypedMarker
import com.dataart.catalyst.util.datadsl.dsl.By
import com.dataart.catalyst.util.datadsl.dsl.Query
import com.dataart.catalyst.util.datadsl.dsl.SortOrder
import com.dataart.catalyst.util.datadsl.dsl.and
import com.dataart.catalyst.util.datadsl.dsl.equalsTo
import com.dataart.catalyst.util.datadsl.dsl.moreOrEqualsThan
import com.dataart.catalyst.util.datadsl.dsl.not
import com.dataart.catalyst.util.datadsl.visitor.SqlGeneratingVisitor

val name = TypedMarker.create<String>("name")
val surname = TypedMarker.create<String>("surname")
val age = TypedMarker.create<Int>("age")

fun main() {
    val query0: Query = Query.builder()
        .select(name, age)
        .where(name equalsTo "Luke")
        .build()
    val query1: Query = Query.builder()
        .select(name, surname, age)
        .where(name equalsTo surname)
        .sort(By(name), By(age, SortOrder.Descending))
        .build()
    val query2: Query = Query.builder()
        .select(name, age)
        .where(not((name equalsTo "Luke") and (age moreOrEqualsThan 40)))
        .sort(By(name))
        .limit(20)
        .build()

    val executor = SqlExecutor()

    val generator = SqlGeneratingVisitor()

    val sql0 = query0.accept(generator)
    println("-------------------------")
    println(sql0)
    println(query1.accept(generator))
    println(query2.accept(generator))
    println(Query.builder().select().build().accept(generator))
    println("-------------------------")

    val result = executor.execute(query0)
//    val result = executor.execute(query0).single()

    for (record in result) {
        println()
        println("Name: ${record.get(name)}")
        println("Age: ${record.get(age)}")
    }
}
