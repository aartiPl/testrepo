package com.dataart.catalyst.util.marker

import assertk.all
import assertk.assertThat
import assertk.assertions.endsWith
import assertk.assertions.isEqualTo
import assertk.assertions.prop
import assertk.assertions.startsWith
import nl.jqno.equalsverifier.EqualsVerifier
import org.junit.jupiter.api.Test

internal class TypedMarkerTest {
    @Test
    fun `Assert that TypedMarked is constructed correctly`() {
        assertThat(TypedMarker.create<Int>("Test int property")).apply {
            prop(TypedMarker<Int>::clazz).transform { it.name }
                .isEqualTo("java.lang.Integer")
            prop(TypedMarker<Int>::name).isEqualTo("Test int property")
        }

        assertThat(TypedMarker.create<Double>("Value of PI")).apply {
            prop(TypedMarker<Double>::clazz).transform { it.name }
                .isEqualTo("java.lang.Double")
            prop(TypedMarker<Double>::name).isEqualTo("Value of PI")
        }
    }

    @Test
    fun `Assert that TypedMarkers are always different by 'name' field`() {
        var counter = 0
        val list = generateSequence { TypedMarker.create<Int>("property_${counter++}") }.take(100)
            .toList()

        assertThat(list.size).isEqualTo(
            list.map { it.name }
                .distinct()
                .count()
        )
    }

    @Test
    fun `Assert that Equals and HashCode works correctly`() {
        EqualsVerifier.forClass(TypedMarker::class.java)
            .usingGetClass()
            .withOnlyTheseFields("name")
            .withNonnullFields()
            .verify()
    }

    @Test
    fun `Assert that toString() works correctly`() {
        assertThat(
            TypedMarker.create<Int>("Test int property")
                .toString()
        ).all {
            startsWith("Marker(")
            endsWith("name='Test int property'[, clazz=class java.lang.Integer])")
        }
        assertThat(
            TypedMarker.create<String>("Test string property")
                .toString()
        ).all {
            startsWith("Marker(")
            endsWith("name='Test string property'[, clazz=class java.lang.String])")
        }
    }
}
