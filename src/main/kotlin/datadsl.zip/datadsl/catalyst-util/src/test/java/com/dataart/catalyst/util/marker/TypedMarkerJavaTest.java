package com.dataart.catalyst.util.marker;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class TypedMarkerJavaTest {
    @Test
    void testCreate() {
        assertThat(TypedMarker.create("test", Integer.class).getName()).isEqualTo("test");
    }
}
