import java.time.Clock

plugins {
    kotlin("jvm") version "1.7.20"
    signing
    id("java-gradle-plugin")
    id("maven-publish")
    id("com.github.gmazzo.buildconfig") version "3.1.0"
}

group = "com.paraport.gradlecommon"
version = "1.0.0-SNAPSHOT"

repositories {
    mavenCentral()
    gradlePluginPortal()
}

buildConfig {
    packageName(project.group.toString())
    useKotlinOutput()

    buildConfigField("String", "APP_NAME", "\"${project.name}\"")
    buildConfigField("String", "APP_VERSION", "\"${project.version}\"")
    buildConfigField("String", "APP_BUILD_TIME", "\"${Clock.systemUTC().instant()}\"")
}

gradlePlugin {
    plugins {
        create("CommonPlugin") {
            id = "com.paraport.gradle-common"
            implementationClass = "${project.group}.CommonPlugin"
        }
    }
}

dependencies {
    implementation("org.jetbrains.kotlin:kotlin-gradle-plugin:1.7.20")
    implementation("org.jetbrains.kotlinx:kover:0.6.1")
    implementation("io.gitlab.arturbosch.detekt:detekt-gradle-plugin:1.21.0")
    implementation("io.gitlab.arturbosch.detekt:detekt-formatting:1.21.0")
    implementation("org.jetbrains.dokka:dokka-gradle-plugin:1.7.20")
    implementation("com.github.gmazzo:gradle-buildconfig-plugin:3.1.0")
}

java {
    withJavadocJar()
    withSourcesJar()
}

publishing {
    publications {
        create<MavenPublication>("gradleCommonPublish") {
            from(components["kotlin"])
        }
    }

    repositories {
        maven {
            name = "repo"
            credentials {
                username = ""
                password = ""
            }
            url = uri(layout.buildDirectory.dir("repo"))
        }
    }
}

signing {
    sign(publishing.publications["gradleCommonPublish"])
}

tasks.withType<org.jetbrains.kotlin.gradle.tasks.KotlinCompile> {
    kotlinOptions.jvmTarget = "1.8"
}
