package com.paraport.gradlecommon.configurer

import com.paraport.gradlecommon.extension.CommonExtension
import com.github.gmazzo.gradle.plugins.BuildConfigExtension
import com.github.gmazzo.gradle.plugins.BuildConfigPlugin
import org.gradle.api.Project
import java.time.Clock

class BuildConfigConfigurer : Configurer {
    override fun configure(project: Project, extensionConfig: CommonExtension) {
        project.allprojects { each ->
            each.pluginManager.apply(BuildConfigPlugin::class.java)

            each.extensions.configure(BuildConfigExtension::class.java) {
                it.packageName(each.group.toString())

                it.useKotlinOutput()

                it.buildConfigField("String", "APP_NAME", "\"${each.name}\"")
                it.buildConfigField("String", "APP_VERSION", "\"${each.version}\"")
                it.buildConfigField("String", "APP_BUILD_TIME", "\"${Clock.systemUTC().instant()}\"")
            }
        }
    }
}
