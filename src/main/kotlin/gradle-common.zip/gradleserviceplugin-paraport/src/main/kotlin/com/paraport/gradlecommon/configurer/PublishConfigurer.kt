package com.paraport.gradlecommon.configurer

import com.paraport.gradlecommon.extension.CommonExtension
import org.gradle.api.Project
import org.gradle.api.publish.PublishingExtension
import org.gradle.api.publish.maven.MavenPublication
import org.gradle.plugins.signing.SigningExtension

class PublishConfigurer : Configurer {

    override fun configure(project: Project, extensionConfig: CommonExtension) {
        project.pluginManager.apply("org.gradle.signing")
        project.pluginManager.apply("maven-publish")

        project.extensions.configure(PublishingExtension::class.java) { publishingExtension ->
            val publication = publishingExtension.publications.create("commonPublish", MavenPublication::class.java) {
                it.from(project.components.findByName("kotlin"))
            }
            publishingExtension.repositories { repositoryHandler ->
                repositoryHandler.maven { repository ->
                    repository.name = extensionConfig.publishProperties.repositoryName
                    repository.credentials {
                        it.username = extensionConfig.publishProperties.userName
                        it.password = extensionConfig.publishProperties.password
                    }
                    repository.url = project.uri(project.layout.buildDirectory.dir(extensionConfig.publishProperties.repositoryUrl))
                }
            }

            project.extensions.configure(SigningExtension::class.java) {
                it.sign(publication)
            }
        }
    }
}
