package com.paraport.gradlecommon.extension

data class CodeStyleProperties(
    var maxViolationsAllowed: Int = 0
)
