package com.paraport.gradlecommon.configurer

import com.paraport.gradlecommon.extension.CommonExtension
import io.gitlab.arturbosch.detekt.DetektPlugin
import io.gitlab.arturbosch.detekt.extensions.DetektExtension
import org.gradle.api.Project
import java.io.File
import java.nio.charset.StandardCharsets
import java.nio.file.Files
import java.nio.file.Paths

class DetektConfigurer : Configurer {

    override fun configure(project: Project, extensionConfig: CommonExtension) {
        project.allprojects {
            val configLocation = "${it.buildDir}/tmp/detekt.yml"

            Files.createDirectories(Paths.get("${it.buildDir}/tmp"))
            val content = DetektConfigurationFile.content
                .replace("{maxIssues}", extensionConfig.codeStyleProperties.maxViolationsAllowed.toString())
            File(configLocation).writeText(
                content,
                StandardCharsets.UTF_8
            )

            it.pluginManager.apply(DetektPlugin::class.java)

            it.extensions.configure(DetektExtension::class.java) { detektConfig ->
                detektConfig.debug = true
                detektConfig.parallel = true
                detektConfig.config = it.files(configLocation)
            }
        }
    }
}
