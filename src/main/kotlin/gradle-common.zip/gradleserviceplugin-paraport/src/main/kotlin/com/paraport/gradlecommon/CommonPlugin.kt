package com.paraport.gradlecommon

import com.paraport.gradlecommon.configurer.*
import com.paraport.gradlecommon.extension.CommonExtension
import org.gradle.api.Plugin
import org.gradle.api.Project

private const val EXTENSION_NAME = "commonGradleConfig"

private val configurers: List<Configurer> = listOf(
    KoverConfigurer(),
    DokkaConfigurer(),
    DetektConfigurer(),
    CompilationConfigurer(),
    RepositoriesConfigurer(),
    TestConfigurer(),
    PublishConfigurer(),
    BuildConfigConfigurer()
)

@Suppress("unused")
class CommonPlugin : Plugin<Project> {

    override fun apply(project: Project) {
        println("`${BuildConfig.APP_NAME}` plugin, version ${BuildConfig.APP_VERSION} (${BuildConfig.APP_BUILD_TIME})")
        val extensionConfig = project.extensions.create(EXTENSION_NAME, CommonExtension::class.java)

        configurers.forEach { it.initialize(project, extensionConfig) }
        project.afterEvaluate {
            configurers.forEach { it.configure(project, extensionConfig) }
        }
    }
}
