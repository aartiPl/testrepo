package com.paraport.gradlecommon.extension

@Suppress("unused")
open class CommonExtension {
    internal var testCoverageProperties: TestCoverageProperties = TestCoverageProperties()
    internal var codeStyleProperties: CodeStyleProperties = CodeStyleProperties()
    internal var publishProperties: PublishProperties = PublishProperties()

    fun testCoverage(action: TestCoverageProperties.() -> Unit) {
        testCoverageProperties.apply(action)
    }

    fun codeStyle(action: CodeStyleProperties.() -> Unit) {
        codeStyleProperties.apply(action)
    }

    fun publishProperties(action: PublishProperties.() -> Unit) {
        publishProperties.apply(action)
    }
}
