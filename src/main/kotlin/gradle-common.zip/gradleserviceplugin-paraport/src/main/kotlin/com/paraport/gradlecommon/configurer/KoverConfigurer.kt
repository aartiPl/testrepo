package com.paraport.gradlecommon.configurer

import com.paraport.gradlecommon.extension.CommonExtension
import kotlinx.kover.KoverPlugin
import kotlinx.kover.api.CounterType
import kotlinx.kover.api.KoverMergedConfig
import kotlinx.kover.api.VerificationTarget
import kotlinx.kover.api.VerificationValueType
import org.gradle.api.Project

class KoverConfigurer : Configurer {

    override fun configure(project: Project, extensionConfig: CommonExtension) {
        project.allprojects {
            it.pluginManager.apply(KoverPlugin::class.java)
        }

        project.extensions.configure(KoverMergedConfig::class.java) { koverMergedConfig ->
            koverMergedConfig.enable()
            koverMergedConfig.filters { filters ->
                filters.classes { classes ->
                    classes.excludes.add("*BuildConfig*")
                    classes.excludes.addAll(extensionConfig.testCoverageProperties.excludeClasses)
                }
            }

            koverMergedConfig.htmlReport { htmlReport ->
                htmlReport.onCheck.set(true)
            }

            koverMergedConfig.verify { verifyConfig ->
                verifyConfig.rule { lineRule ->
                    lineRule.isEnabled = true
                    lineRule.target = VerificationTarget.ALL

                    lineRule.bound { bound ->
                        bound.minValue = extensionConfig.testCoverageProperties.testLinesCoverage
                        bound.counter = CounterType.LINE
                        bound.valueType = VerificationValueType.COVERED_PERCENTAGE
                    }
                }

                verifyConfig.rule { instructionRule ->
                    instructionRule.isEnabled = true
                    instructionRule.target = VerificationTarget.ALL

                    instructionRule.bound { bound ->
                        bound.minValue = extensionConfig.testCoverageProperties.testInstructionCoverage
                        bound.counter = CounterType.INSTRUCTION
                        bound.valueType = VerificationValueType.COVERED_PERCENTAGE
                    }
                }

                verifyConfig.rule { branchRule ->
                    branchRule.isEnabled = true
                    branchRule.target = VerificationTarget.ALL

                    branchRule.bound { bound ->
                        bound.minValue = extensionConfig.testCoverageProperties.testBranchCoverage
                        bound.counter = CounterType.BRANCH
                        bound.valueType = VerificationValueType.COVERED_PERCENTAGE
                    }
                }
            }
        }
    }
}
