package com.paraport.gradlecommon.configurer

import com.paraport.gradlecommon.extension.CommonExtension
import org.gradle.api.Project

class RepositoriesConfigurer : Configurer {

    override fun configure(project: Project, extensionConfig: CommonExtension) {
        project.allprojects {
            it.repositories.mavenCentral()
        }
    }
}
