package com.paraport.gradlecommon.configurer

import com.paraport.gradlecommon.extension.CommonExtension
import org.gradle.api.Project
import org.jetbrains.kotlin.gradle.tasks.KotlinCompile

class CompilationConfigurer : Configurer {

    override fun configure(project: Project, extensionConfig: CommonExtension) {
        project.allprojects {
            it.tasks.withType(KotlinCompile::class.java) { kotlin ->
                kotlin.kotlinOptions.jvmTarget = "1.8"
            }
        }
    }
}
