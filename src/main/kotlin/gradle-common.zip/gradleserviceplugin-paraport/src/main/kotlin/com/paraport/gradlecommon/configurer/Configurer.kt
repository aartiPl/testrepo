package com.paraport.gradlecommon.configurer

import com.paraport.gradlecommon.extension.CommonExtension
import org.gradle.api.Project

interface Configurer {

    /**
     * This function is called during project evaluation.
     *
     * @param project target project
     * @param extensionConfig container for properties
     */
    fun initialize(project: Project, extensionConfig: CommonExtension) {
        // do nothing by default
    }

    /**
     * This function is called after project evaluation.
     *
     * @param project target project
     * @param extensionConfig container for properties
     */
    fun configure(project: Project, extensionConfig: CommonExtension)

}
