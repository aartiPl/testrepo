package com.paraport.gradlecommon.extension

data class PublishProperties(
    var repositoryName: String = "repoName",
    var userName: String = "user",
    var password: String = "pass",
    var repositoryUrl: String = "repo url",
)
