package com.paraport.gradlecommon.extension

data class TestCoverageProperties(
    var excludeClasses: Collection<String> = listOf(),
    var testLinesCoverage: Int = 100,
    var testInstructionCoverage: Int = 100,
    var testBranchCoverage: Int = 100
)
