package com.paraport.catalyst.spring

fun main() {
    println("Spring")
}
