package com.paraport.catalyst.database

fun main() {
    println("Database")
}
