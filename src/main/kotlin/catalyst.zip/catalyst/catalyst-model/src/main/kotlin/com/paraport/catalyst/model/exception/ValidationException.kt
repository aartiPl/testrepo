package com.paraport.catalyst.model.exception

class ValidationException(message: String) : RuntimeException(message)
