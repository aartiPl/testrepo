package com.paraport.catalyst.model.finance

import com.paraport.catalyst.model.Validator.exactLength
import com.paraport.catalyst.model.Validator.validateAndThrowOnFailure
import io.konform.validation.Validation
import io.konform.validation.jsonschema.pattern
import org.apache.commons.validator.routines.ISINValidator

data class Isin(val value: String) {
    init {
        validator.validateAndThrowOnFailure(
            this,
            "Isin '$value' is invalid. It has to be 12 character string with first two letters as country code:"
        )
    }

    companion object {
        private val validator = Validation {
            Isin::value {
                exactLength(12)
                pattern("^([A-Z]{2}).*$") hint "Must start with first two uppercase letters as country code"
                addConstraint("Checksums for ISIN are invalid") {
                    ISINValidator.getInstance(true).isValid(it)
                }
            }
        }
    }
}
