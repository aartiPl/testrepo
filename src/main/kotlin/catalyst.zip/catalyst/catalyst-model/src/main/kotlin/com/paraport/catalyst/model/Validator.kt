package com.paraport.catalyst.model

import com.paraport.catalyst.model.exception.ValidationException
import io.konform.validation.Invalid
import io.konform.validation.Validation
import io.konform.validation.ValidationBuilder

object Validator {

    fun <T> Validation<T>.validateAndThrowOnFailure(value: T, prefixMessage: String) {
        val result = validate(value)

        if (result is Invalid) {
            val message = prefixMessage + result.errors.joinToString("\n", "\n") {
                "* ${it.dataPath}: ${it.message}"
            }

            throw ValidationException(message)
        }
    }

    fun ValidationBuilder<String>.exactLength(length: Int) =
        addConstraint("String has to be exactly of $length length") { it.length == length }
}
