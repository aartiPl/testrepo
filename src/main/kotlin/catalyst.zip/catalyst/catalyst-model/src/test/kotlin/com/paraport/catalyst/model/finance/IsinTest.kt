package com.paraport.catalyst.model.finance

import assertk.assertThat
import assertk.assertions.isEqualTo
import assertk.assertions.isFailure
import assertk.assertions.isInstanceOf
import assertk.assertions.message
import assertk.assertions.messageContains
import com.paraport.catalyst.model.exception.ValidationException
import org.junit.jupiter.api.Test

class IsinTest {

    @Test
    fun `Assert that Isin is validating correctly`() {
        assertThat(Isin("US0378331005").value).isEqualTo("US0378331005")
        assertThat(Isin("XS0356705219").value).isEqualTo("XS0356705219")

        assertThat { Isin("LL1111111111") }.isFailure().isInstanceOf(ValidationException::class.java)
            .messageContains("Checksums for ISIN are invalid")

        assertThat { Isin("LL12345678900") }.isFailure().isInstanceOf(ValidationException::class.java)
            .messageContains("String has to be exactly of 12 length")

        val testMessage = """
            |Isin 'L012345678900' is invalid. It has to be 12 character string with first two letters as country code:
            |* .value: String has to be exactly of 12 length
            |* .value: Must start with first two uppercase letters as country code
            |* .value: Checksums for ISIN are invalid
                """.trimMargin()
        assertThat { Isin("L012345678900") }.isFailure().isInstanceOf(ValidationException::class.java).apply {
            message().isEqualTo(testMessage)
        }
    }
}
