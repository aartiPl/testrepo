package com.paraport.catalyst.model.finance;

import com.paraport.catalyst.model.exception.ValidationException;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.assertj.core.api.AssertionsForClassTypes.catchThrowable;

class IsinJavaTest {

  @Test
  public void assertThatIsinIsValidatingCorrectly() {
    assertThat(new Isin("US0378331005").getValue()).isEqualTo("US0378331005");
    assertThat(new Isin("XS0356705219").getValue()).isEqualTo("XS0356705219");

    assertThat(catchThrowable(() -> new Isin("LL1111111111")))
        .isInstanceOf(ValidationException.class)
        .hasMessageContaining("Isin 'LL1111111111' is invalid. It has to be 12 character string with first two letters as country code")
        .hasMessageContaining("Checksums for ISIN are invalid");

    assertThat(catchThrowable(() -> new Isin("LL12345678900")))
        .isInstanceOf(ValidationException.class)
        .hasMessageContaining("String has to be exactly of 12 length")
        .hasMessageContaining("Checksums for ISIN are invalid");
  }
}
