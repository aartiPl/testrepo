dependencies {
    implementation("io.konform:konform:0.4.0")
    implementation("commons-validator:commons-validator:1.7") {
        exclude(group = "commons-collections", module = "commons-collections")
    }
}
