plugins {
    kotlin("jvm") version "1.7.20"
}

buildscript {
    repositories {
        mavenLocal()
        mavenCentral()
    }

    dependencies {
        classpath("com.dataart.gradlecommon:gradle-common:1.0.0-SNAPSHOT")
    }
}

apply(plugin = "com.dataart.gradle-common")

configure<com.dataart.gradlecommon.extension.CommonExtension> {
    testCoverage {
        excludeClasses = listOf("*MainKt")
        testLinesCoverage = 100
        testInstructionCoverage = 100
        testBranchCoverage = 100
    }
    codeStyle {
        maxViolationsAllowed = 0
    }
}

group = "com.dataart.catalyst"
version = "1.0.0-SNAPSHOT"

subprojects {
    apply(plugin = "org.jetbrains.kotlin.jvm")

    dependencies {
        testImplementation(kotlin("test"))
        testImplementation("com.willowtreeapps.assertk:assertk:0.25")
        testImplementation("org.assertj:assertj-core:3.23.1")
        testImplementation("nl.jqno.equalsverifier:equalsverifier:3.10.1")
    }
}
