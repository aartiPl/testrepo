package com.paraport.catalyst.aws

fun main() {
    println("AWS")
}
