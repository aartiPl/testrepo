package com.paraport.catalyst.util.generator

interface Generator<T> {
    fun next(): T
}
