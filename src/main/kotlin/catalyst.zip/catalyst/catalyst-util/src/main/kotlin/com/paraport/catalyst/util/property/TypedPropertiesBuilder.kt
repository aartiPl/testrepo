package com.paraport.catalyst.util.property

import com.paraport.catalyst.util.marker.Marker
import com.paraport.catalyst.util.marker.TypedMarker

@Suppress("MemberVisibilityCanBePrivate")
class TypedPropertiesBuilder internal constructor() {
    private val map = mutableMapOf<Marker, Any?>()

    fun <T> addProperty(marker: TypedMarker<T>, value: T) = apply {
        map[marker] = value
    }

    fun build(): TypedProperties {
        return TypedProperties(map)
    }
}
