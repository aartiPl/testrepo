package com.paraport.catalyst.util.resource

import java.net.URL
import java.util.*

/**
 * This is utility class to work with class loader resources (classpath, resources folder, etc.).
 */
object Resource {

    /**
     * Finds the resource with the given name.
     * A resource is some data (images, audio, text, etc) that can be accessed by class code in a way that is independent of the location of the code.
     * The name of a resource is a '/'-separated path name that identifies the resource.
     * Resources in named modules are subject to the encapsulation rules specified by Module.getResourceAsStream.
     * Additionally, and except for the special case where the resource has a name ending with ".class", this method will only find resources in packages of named modules when the package is opened unconditionally (even if the caller of this method is in the same module as the resource).
     *
     * @param resourcePath the resource name
     * @return URL object for reading the resource; null if the resource could not be found, a URL could not be constructed to locate the resource, the resource is in a package that is not opened unconditionally, or access to the resource is denied by the security manager.
     * @throws NullPointerException if resourcePath is null
     */
    @JvmStatic
    fun find(resourcePath: String): URL? {
        val loader = Objects.requireNonNullElse(
            Thread.currentThread().contextClassLoader, Resource::class.java.classLoader
        )
        return loader.getResource(resourcePath)
    }

    /**
     * Checks whether resource with the provided path exists.
     *
     * @param resourcePath the resource name
     * @return true if resource exists, false otherwise
     * @throws NullPointerException if resourcePath is null
     */
    @JvmStatic
    fun exists(resourcePath: String) = find(resourcePath) != null

    /**
     * Returns the entire content of resource found by its name as a String using UTF-8 or the specified charset.
     *
     * @param resourcePath the resource name
     * @return a string of the entire resource content
     * @throws NullPointerException If resourcePath is null
     * @throws IllegalArgumentException if resource wasn't found
     */
    @JvmStatic
    fun asString(resourcePath: String): String {
        return find(resourcePath)?.readText()
            ?: throw IllegalArgumentException("Invalid or non-existing resourcePath '$resourcePath'")
    }
}
