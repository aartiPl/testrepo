package com.paraport.catalyst.util.annotation

@MustBeDocumented
annotation class OnlyKotlinCode
