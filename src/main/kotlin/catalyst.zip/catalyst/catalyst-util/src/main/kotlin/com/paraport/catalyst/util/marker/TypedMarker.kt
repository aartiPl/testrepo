package com.paraport.catalyst.util.marker

import com.paraport.catalyst.util.annotation.OnlyKotlinCode

class TypedMarker<T> private constructor(
    override val clazz: Class<T>, override val label: String
) : Marker(clazz, label) {
    companion object {
        @JvmStatic
        fun <T> create(clazz: Class<T>, name: String) = TypedMarker(clazz, name)

        @OnlyKotlinCode
        inline fun <reified T> create(name: String) = create(T::class.java, name)
    }
}
