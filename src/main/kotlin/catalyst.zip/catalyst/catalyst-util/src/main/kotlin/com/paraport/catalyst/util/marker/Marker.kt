package com.paraport.catalyst.util.marker

import com.paraport.catalyst.util.generator.IntGenerator

@Suppress("UnnecessaryAbstractClass")
abstract class Marker(open val clazz: Class<*>, open val label: String) {
    val id: Int = intGenerator.next()

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as Marker

        if (id != other.id) return false

        return true
    }

    override fun hashCode(): Int {
        return id
    }

    override fun toString(): String {
        return "Marker(id=$id, [label='$label', clazz=$clazz])"
    }

    companion object {
        private val intGenerator = IntGenerator()
    }
}
