package com.paraport.catalyst.util.resource;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.assertj.core.api.AssertionsForClassTypes.catchThrowable;

public class ResourceJavaTest {

  private static final String TEST_FILE_NAME = "test.txt";

  @Test
  public void testFindThrowsNullPointerExceptionForNullResourceName() {
    assertThat(catchThrowable(() -> Resource.find(null)))
        .isInstanceOf(NullPointerException.class);
  }

  @Test
  public void testFind() {
    assertThat(Resource.find(TEST_FILE_NAME)).isNotNull();
  }

  @Test
  public void testAsString() {
    assertThat(Resource.asString(TEST_FILE_NAME)).isNotNull();
    assertThat(catchThrowable(() -> Resource.asString("someNonExistingResource")))
        .isInstanceOf(IllegalArgumentException.class)
        .hasMessageContaining("Invalid or non-existing resourcePath 'someNonExistingResource'");
  }

  @Test
  public void testExists() {
    assertThat(Resource.exists(TEST_FILE_NAME)).isNotNull();
  }
}
