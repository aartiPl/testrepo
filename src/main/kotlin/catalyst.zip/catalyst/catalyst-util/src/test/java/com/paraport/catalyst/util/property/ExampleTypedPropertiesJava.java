package com.paraport.catalyst.util.property;

import com.paraport.catalyst.util.marker.TypedMarker;

@SuppressWarnings("unused")
class ExamplePersonJava {
  private final String name;
  private final String surname;

  ExamplePersonJava(String name, String surname) {
    this.name = name;
    this.surname = surname;
  }

  public String getName() {
    return name;
  }

  public String getSurname() {
    return surname;
  }
}

public class ExampleTypedPropertiesJava {
  static TypedMarker<Integer> timeout = TypedMarker.create(Integer.class, "timeout value");
  static TypedMarker<String> name = TypedMarker.create(String.class, "name");
  static TypedMarker<String> description = TypedMarker.create(String.class, "description");
  static TypedMarker<Double> ratio = TypedMarker.create(Double.class, "request ration before upscaling");
  static TypedMarker<ExamplePersonJava> nonExistingPerson = TypedMarker.create(ExamplePersonJava.class, "person property");
}
