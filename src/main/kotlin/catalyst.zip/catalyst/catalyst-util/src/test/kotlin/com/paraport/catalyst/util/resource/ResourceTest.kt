package com.paraport.catalyst.util.resource

import assertk.assertThat
import assertk.assertions.hasMessage
import assertk.assertions.isEqualTo
import assertk.assertions.isFailure
import assertk.assertions.isNull
import assertk.assertions.matchesPredicate
import org.junit.jupiter.api.Test

internal class ResourceTest {
    @Test
    fun `Assert that find() returns null if can't locate resource`() {
        assertThat(Resource.find("invalid-file.txt")).isNull()
    }

    @Test
    fun `Assert that find() can locate resource`() {
        assertThat(Resource.find("test.txt"))
            .matchesPredicate { it.toString().endsWith("catalyst-util/build/resources/test/test.txt") }
    }

    @Test
    fun `Assert that find() can locate resource with subdirectory`() {
        assertThat(Resource.find("foo/bar/subdirectory-file.txt"))
            .matchesPredicate {
                it.toString()
                    .endsWith("catalyst-util/build/resources/test/foo/bar/subdirectory-file.txt")
            }
    }

    @Test
    fun `Assert that exists() can locate resource`() {
        assertThat(Resource.exists("test.txt")).isEqualTo(true)
    }

    @Test
    fun `Assert that exists() can locate resource with subdirectory`() {
        assertThat(Resource.exists("foo/bar/subdirectory-file.txt")).isEqualTo(true)
    }

    @Test
    fun `Assert that exists() returns false if resource doesn't exist`() {
        assertThat(Resource.exists("invalid-file.txt")).isEqualTo(false)
    }

    @Test
    fun `Assert that asString() can return resource as string`() {
        assertThat(Resource.asString("test.txt")).isEqualTo("hello")
    }

    @Test
    fun `Assert that asString() returns resource with subdirectory as string`() {
        assertThat(Resource.asString("foo/bar/subdirectory-file.txt")).isEqualTo("subdirectory")
    }

    @Test
    fun `Assert that asString() throws exception if resource doesn't exist`() {
        assertThat { Resource.asString("invalid-file.txt") }
            .isFailure()
            .hasMessage("Invalid or non-existing resourcePath 'invalid-file.txt'")
    }
}
