package com.paraport.catalyst.util.property;

import com.paraport.catalyst.util.marker.Marker;
import java.util.NoSuchElementException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static com.paraport.catalyst.util.property.ExampleTypedPropertiesJava.description;
import static com.paraport.catalyst.util.property.ExampleTypedPropertiesJava.name;
import static com.paraport.catalyst.util.property.ExampleTypedPropertiesJava.nonExistingPerson;
import static com.paraport.catalyst.util.property.ExampleTypedPropertiesJava.ratio;
import static com.paraport.catalyst.util.property.ExampleTypedPropertiesJava.timeout;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;

public class TypedPropertiesJavaTest {
  private TypedProperties properties;

  @BeforeEach
  void setUp() {
    properties = TypedProperties.builder().addProperty(timeout, 120).addProperty(name, "sophisticatedService").addProperty(description, null).addProperty(ratio, 1.9).build();
  }

  @Test
  void checkAccessorsFromJava() {
    assertThat(properties.get((Marker) timeout)).isEqualTo(120);
    assertThat(properties.get(timeout)).isEqualTo(120);
    assertThat(properties.getOrThrow(timeout)).isEqualTo(120);
    assertThat(catchThrowable(() -> properties.getOrThrow(nonExistingPerson))).isInstanceOf(NoSuchElementException.class);
    assertThat(properties.getOrDefault(timeout, 15)).isEqualTo(120);
    assertThat(properties.getOrElse(timeout, () -> 15)).isEqualTo(120);
    assertThat(properties.size()).isEqualTo(4);
    assertThat(properties.entries()).isNotEmpty();
    assertThat(properties.keys()).isNotEmpty();
    assertThat(properties.values()).isNotEmpty();
    assertThat(properties.isEmpty()).isEqualTo(false);
    assertThat(properties.isEmpty()).isEqualTo(false);
    assertThat(properties.iterator()).isNotNull();
    assertThat(properties.containsKey(ratio)).isEqualTo(true);
    assertThat(properties.containsValue(1.9)).isEqualTo(true);
  }
}
