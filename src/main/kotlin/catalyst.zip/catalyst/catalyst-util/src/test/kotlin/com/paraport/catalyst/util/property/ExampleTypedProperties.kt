package com.paraport.catalyst.util.property

import com.paraport.catalyst.util.marker.TypedMarker

data class ExamplePerson(val name: String, val surname: String)

object ExamplePersonInstances {
    val marcinIksinski = ExamplePerson("Marcin", "Iksiński")
}

object ExampleTypedProperties {
    @JvmStatic
    val timeout = TypedMarker.create<Int>("timeout value")
    @JvmStatic
    val name = TypedMarker.create<String>("name")
    @JvmStatic
    val description = TypedMarker.create<String?>("description")
    @JvmStatic
    val ratio = TypedMarker.create<Double>("request ration before upscaling")
    @JvmStatic
    val nonExistingPerson = TypedMarker.create<ExamplePerson>("person property")
}
