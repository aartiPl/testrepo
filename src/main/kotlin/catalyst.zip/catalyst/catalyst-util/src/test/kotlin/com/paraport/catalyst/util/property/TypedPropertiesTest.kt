package com.paraport.catalyst.util.property

import assertk.assertThat
import assertk.assertions.containsExactlyInAnyOrder
import assertk.assertions.isEqualTo
import assertk.assertions.isFailure
import assertk.assertions.isInstanceOf
import assertk.assertions.isNull
import assertk.assertions.messageContains
import com.paraport.catalyst.util.marker.Marker
import com.paraport.catalyst.util.property.ExampleTypedProperties.description
import com.paraport.catalyst.util.property.ExampleTypedProperties.name
import com.paraport.catalyst.util.property.ExampleTypedProperties.nonExistingPerson
import com.paraport.catalyst.util.property.ExampleTypedProperties.ratio
import com.paraport.catalyst.util.property.ExampleTypedProperties.timeout
import java.util.AbstractMap.SimpleEntry
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test

internal class TypedPropertiesTest {
    private lateinit var properties: TypedProperties

    @BeforeEach
    fun setUp() {
        properties = TypedProperties.builder()
            .addProperty(timeout, 120)
            .addProperty(name, "sophisticatedService")
            .addProperty(description, null)
            .addProperty(ratio, 1.9)
            .build()
    }

    @Test
    fun `Assert that untyped get() accessor works correctly`() {
        assertThat(properties.get(timeout as Marker)).isEqualTo(120)
        assertThat(properties.get(name as Marker)).isEqualTo("sophisticatedService")
        assertThat(properties.get(description as Marker)).isNull()
        assertThat(properties.get(ratio as Marker)).isEqualTo(1.9)
        assertThat(properties.get(nonExistingPerson as Marker)).isNull()
    }

    @Test
    fun `Assert that get() accessor works correctly`() {
        assertThat(properties.get(timeout)).isEqualTo(120)
        assertThat(properties.get(name)).isEqualTo("sophisticatedService")
        assertThat(properties.get(description)).isNull()
        assertThat(properties.get(ratio)).isEqualTo(1.9)
        assertThat(properties.get(nonExistingPerson)).isNull()
    }

    @Test
    fun `Assert that getOrThrow() accessor works correctly`() {
        assertThat(properties.getOrThrow(timeout)).isEqualTo(120)
        assertThat(properties.getOrThrow(description)).isNull()

        assertThat { properties.getOrThrow(nonExistingPerson) }.isFailure()
            .isInstanceOf(NoSuchElementException::class.java)
            .messageContains("is missing in the properties.")
    }

    @Test
    fun `Assert that getOrDefault() accessor works correctly`() {
        assertThat(properties.getOrDefault(timeout, 15)).isEqualTo(120)
        assertThat(properties.getOrDefault(description, "Description")).isNull()

        assertThat(properties.getOrDefault(nonExistingPerson, ExamplePersonInstances.marcinIksinski)).isEqualTo(
            ExamplePersonInstances.marcinIksinski
        )
    }

    @Test
    fun `Assert that getOrElse() accessor works correctly`() {
        assertThat(properties.getOrElse(timeout) { 15 }).isEqualTo(120)
        assertThat(properties.getOrElse(description) { "Description" }).isNull()

        assertThat(properties.getOrElse(nonExistingPerson) { ExamplePersonInstances.marcinIksinski }).isEqualTo(
            ExamplePersonInstances.marcinIksinski
        )
    }

    @Test
    fun `Assert that properties collection can be correctly queried`() {
        assertThat(properties.size).isEqualTo(4)
        assertThat(properties.entries).isEqualTo(
            setOf(
                SimpleEntry(timeout, 120),
                SimpleEntry(name, "sophisticatedService"),
                SimpleEntry(description, null),
                SimpleEntry(ratio, 1.9)
            )
        )
        assertThat(properties.keys).isEqualTo(setOf(timeout, name, description, ratio))
        assertThat(properties.values).containsExactlyInAnyOrder(120, "sophisticatedService", null, 1.9)
        assertThat(properties.isEmpty()).isEqualTo(false)
    }

    @Test
    fun `Assert that it is possible to iterate over properties`() {
        val iterator = properties.iterator()

        assertThat(iterator.hasNext()).isEqualTo(true)
        assertThat(iterator.next()).isEqualTo(SimpleEntry(timeout, 120))
        assertThat(iterator.next()).isEqualTo(SimpleEntry(name, "sophisticatedService"))
        assertThat(iterator.next()).isEqualTo(SimpleEntry(description, null))
        assertThat(iterator.next()).isEqualTo(SimpleEntry(ratio, 1.9))
        assertThat(iterator.hasNext()).isEqualTo(false)
    }

    @Test
    fun `Assert that it is possible to find keys in collection`() {
        assertThat(properties.containsKey(ratio)).isEqualTo(true)
        assertThat(properties.containsKey(description)).isEqualTo(true)
        assertThat(properties.containsKey(nonExistingPerson)).isEqualTo(false)
    }

    @Test
    fun `Assert that it is possible to find values in collection`() {
        assertThat(properties.containsValue(1.9)).isEqualTo(true)
        assertThat(properties.containsValue(null)).isEqualTo(true)
        assertThat(properties.containsValue(25)).isEqualTo(false)
    }
}
