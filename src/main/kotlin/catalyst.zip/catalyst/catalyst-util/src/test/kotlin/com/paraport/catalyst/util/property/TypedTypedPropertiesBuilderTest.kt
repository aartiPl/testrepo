package com.paraport.catalyst.util.property

import assertk.assertThat
import assertk.assertions.isInstanceOf
import assertk.assertions.isNotNull
import com.paraport.catalyst.util.property.TypedProperties
import org.junit.jupiter.api.Test

internal class TypedTypedPropertiesBuilderTest {
    @Test
    fun `Assert that builder accepts values according to defined TypedMarker's`() {
        val properties = TypedPropertiesBuilder()
            .addProperty(ExampleTypedProperties.timeout, 120)
            .addProperty(ExampleTypedProperties.name, "sophisticatedService")
            .addProperty(ExampleTypedProperties.description, null)
            .addProperty(ExampleTypedProperties.ratio, 1.9)
            .build()

        assertThat(properties).isNotNull().isInstanceOf(TypedProperties::class.java)
    }
}
