package com.paraport.catalyst.util.marker

import assertk.all
import assertk.assertThat
import assertk.assertions.endsWith
import assertk.assertions.isEqualTo
import assertk.assertions.prop
import assertk.assertions.startsWith
import nl.jqno.equalsverifier.EqualsVerifier
import org.junit.jupiter.api.Test

internal class TypedMarkerTest {
    @Test
    fun `Assert that TypedMarked is constructed correctly`() {
        assertThat(TypedMarker.create<Int>("Test int property")).apply {
            prop(TypedMarker<Int>::clazz).transform { it.name }.isEqualTo("java.lang.Integer")
            prop(TypedMarker<Int>::label).isEqualTo("Test int property")
        }

        assertThat(TypedMarker.create<Double>("Value of PI")).apply {
            prop(TypedMarker<Double>::clazz).transform { it.name }.isEqualTo("java.lang.Double")
            prop(TypedMarker<Double>::label).isEqualTo("Value of PI")
        }
    }

    @Test
    fun `Assert that TypedMarkers are always different by 'id' field (no duplicates)`() {
        val list = generateSequence { TypedMarker.create<Int>("Test property") }.take(100).toList()

        assertThat(list.size).isEqualTo(list.map { it.id }.distinct().count())
    }

    @Test
    fun `Assert that Equals and HashCode works correctly`() {
        EqualsVerifier.forClass(TypedMarker::class.java).usingGetClass().withIgnoredFields("clazz", "label").verify()
    }

    @Test
    fun `Assert that toString() works correctly`() {
        assertThat(TypedMarker.create<Int>("Test int property").toString()).all {
            startsWith("Marker(id=")
            endsWith(", [label='Test int property', clazz=class java.lang.Integer])")
        }
        assertThat(TypedMarker.create<String>("Test string property").toString()).all {
            startsWith("Marker(id=")
            endsWith(", [label='Test string property', clazz=class java.lang.String])")
        }
    }
}
