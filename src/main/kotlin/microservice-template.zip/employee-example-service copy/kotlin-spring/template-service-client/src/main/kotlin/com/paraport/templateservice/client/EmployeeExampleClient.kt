package com.paraport.templateservice.client

import com.paraport.templateservice.model.Employee
import org.springframework.web.reactive.function.client.WebClient
import org.springframework.web.reactive.function.client.bodyToFlux
import org.springframework.web.reactive.function.client.bodyToMono
import reactor.core.publisher.Flux
import reactor.core.publisher.Mono

class EmployeeExampleClient internal constructor(
    private val client: WebClient
) {
    fun get(id: Int): Mono<Employee> {
        return client.get()
            .uri("$employeePath/$id")
            .retrieve()
            .bodyToMono()
    }

    fun getAll(): Flux<Employee> {
        return client.get()
            .uri(employeePath)
            .retrieve()
            .bodyToFlux()
    }

    companion object {
        private const val employeePath: String = "employees"

        @JvmStatic
        fun builder() = EmployeeExampleClientBuilder()
    }
}
