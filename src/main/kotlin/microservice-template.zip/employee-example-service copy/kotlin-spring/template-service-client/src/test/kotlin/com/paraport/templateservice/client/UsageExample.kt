package com.paraport.templateservice.client

import org.slf4j.Logger
import org.slf4j.LoggerFactory

val logger: Logger = LoggerFactory.getLogger("com.paraport.templateservice.client")

fun main() {
    val employeeExampleClient = EmployeeExampleClient.builder()
        .withBaseUrl("http://localhost:8080")
        .build()

    @Suppress("MagicNumber")
    logger.info("Employee #5:   {}", employeeExampleClient.get(5).block())
    logger.info("All employees: {}", employeeExampleClient.getAll().collectList().block())
}
