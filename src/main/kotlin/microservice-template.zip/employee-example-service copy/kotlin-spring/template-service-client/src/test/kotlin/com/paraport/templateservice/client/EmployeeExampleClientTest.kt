package com.paraport.templateservice.client

import assertk.assertThat
import assertk.assertions.isEqualTo
import assertk.assertions.isFailure
import assertk.assertions.isInstanceOf
import assertk.assertions.isNotNull
import assertk.assertions.messageContains
import com.github.tomakehurst.wiremock.WireMockServer
import org.junit.jupiter.api.AfterAll
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.BeforeAll
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.TestInstance

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
internal class EmployeeExampleClientTest {
    private val wireMockServer: WireMockServer = WireMockServer(8080)

    @BeforeAll
    fun startServer() {
        wireMockServer.start()
    }

    @AfterEach
    fun pauseServer() {
        wireMockServer.shutdown()
    }

    @AfterAll
    fun stopServer() {
        wireMockServer.stop()
    }

    @Test
    fun `Assert that 'get' returns specific employee`() {
        val employeeExampleClient = EmployeeExampleClient.builder()
            .withBaseUrl("http://localhost:8080")
            .build()

        val employee = employeeExampleClient.get(5).block()

        requireNotNull(employee)

        assertThat(employee).isNotNull()
        assertThat(employee.id).isEqualTo(5)
        assertThat(employee.firstName).isEqualTo("Elijah")
        assertThat(employee.lastName).isEqualTo("Whitaker")
        assertThat(employee.email).isEqualTo("elijah.whitaker@mail.com")
    }

    @Test
    fun `Assert that 'getAll' returns list of employees`() {
        val employeeExampleClient = EmployeeExampleClient.builder()
            .withBaseUrl("http://localhost:8080")
            .build()

        val employeeList = employeeExampleClient.getAll().collectList().block()

        requireNotNull(employeeList)

        assertThat(employeeList).isNotNull()
        assertThat(employeeList.size).isEqualTo(8)

        val employee = employeeList[1]
        assertThat(employee.id).isEqualTo(1)
        assertThat(employee.firstName).isEqualTo("Eva")
        assertThat(employee.lastName).isEqualTo("Lawrence")
        assertThat(employee.email).isEqualTo("evalawrence@gmail.com")
    }

    @Test
    fun `Assert that employee client throws exception if parameters invalid`() {
        assertThat { EmployeeExampleClient.builder().build() }
            .isFailure()
            .isInstanceOf(IllegalArgumentException::class)
            .messageContains("Required value was null.")
    }
}
