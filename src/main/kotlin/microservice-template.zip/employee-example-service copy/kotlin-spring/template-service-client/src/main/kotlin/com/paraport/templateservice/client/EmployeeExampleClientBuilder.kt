package com.paraport.templateservice.client

import java.net.URL
import org.springframework.http.HttpHeaders
import org.springframework.http.MediaType
import org.springframework.web.reactive.function.client.WebClient

class EmployeeExampleClientBuilder {
    private var baseUrl: String? = null

    fun withBaseUrl(baseUrl: URL) = apply { this.baseUrl = baseUrl.toString() }

    fun withBaseUrl(baseUrl: String) = apply { this.baseUrl = baseUrl }

    fun build(): EmployeeExampleClient {
        requireNotNull(baseUrl)

        val httpClient = WebClient.builder()
            .baseUrl(baseUrl!!)
            .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .build()

        return EmployeeExampleClient(httpClient)
    }
}
