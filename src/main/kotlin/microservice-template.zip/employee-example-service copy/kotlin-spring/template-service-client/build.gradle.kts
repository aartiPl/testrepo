plugins {
    id("org.springframework.boot") version springVersion apply false
}

dependencies {
    implementation(project(":template-service-model"))

    implementation("org.springframework.boot:spring-boot-starter-webflux")
    implementation("com.fasterxml.jackson.module:jackson-module-kotlin")

    testImplementation("org.springframework.boot:spring-boot-starter-test")
    testImplementation("com.github.tomakehurst:wiremock-jre8:$wireMockVersion")
}
