package com.paraport.templateservice.main.controller

import com.paraport.templateservice.main.service.EmployeeService
import com.paraport.templateservice.model.Employee
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController
import reactor.core.publisher.Flux
import reactor.core.publisher.Mono

@RestController
@RequestMapping("/employees")
class EmployeeController(val employeeService: EmployeeService) {

    @GetMapping("/{id}")
    fun get(@PathVariable id: Int): Mono<Employee> {
        return employeeService.get(id)
    }

    @GetMapping
    fun getAll(): Flux<Employee> {
        return employeeService.getAll()
    }
}
