package com.paraport.templateservice.main.service

import com.paraport.templateservice.main.repository.EmployeeRepository
import com.paraport.templateservice.model.Employee
import org.springframework.stereotype.Service
import reactor.core.publisher.Flux
import reactor.core.publisher.Mono

@Service
class EmployeeService(val employeeRepository: EmployeeRepository) {

    fun get(id: Int): Mono<Employee> {
        return employeeRepository.get(id)
    }

    fun getAll(): Flux<Employee> {
        return employeeRepository.getAll()
    }
}
