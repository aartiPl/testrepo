package com.paraport.templateservice.main.repository

import assertk.all
import assertk.assertThat
import assertk.assertions.isGreaterThanOrEqualTo
import assertk.assertions.isLessThanOrEqualTo
import assertk.assertions.isNotEmpty
import assertk.assertions.isNotNull
import org.junit.jupiter.api.Test

class StaticEmployeeDataStorageTest {
    private val staticEmployeeDataStorage: EmployeeDataStorage = StaticEmployeeDataStorage()

    @Test
    fun `Test that static employee data storage initiated correctly`() {
        assertThat(staticEmployeeDataStorage.getEmployees()).all {
            isNotNull()
            isNotEmpty()
        }

        assertThat(staticEmployeeDataStorage.getEmployees().size).all {
            isGreaterThanOrEqualTo(100)
            isLessThanOrEqualTo(200)
        }
    }
}
