package com.paraport.templateservice.main.repository

import com.paraport.templateservice.model.Employee
import org.springframework.stereotype.Repository
import reactor.core.publisher.Flux
import reactor.core.publisher.Mono

@Repository
class EmployeeRepository(val staticEmployeeDataStorage: StaticEmployeeDataStorage) {

    fun getAll(): Flux<Employee> {
        return Flux.fromIterable(staticEmployeeDataStorage.getEmployees())
    }

    fun get(id: Int): Mono<Employee> {
        return Mono.just(staticEmployeeDataStorage.getEmployees().single { it.id == id })
    }
}
