package com.paraport.templateservice.main.controller

import assertk.assertThat
import assertk.assertions.isEqualTo
import com.paraport.templateservice.client.EmployeeExampleClient
import com.paraport.templateservice.main.repository.EmployeeDataStorage
import org.junit.jupiter.api.BeforeAll
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.TestInstance
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.boot.test.web.server.LocalServerPort

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
internal class EmployeeControllerTest(
    @Autowired private val testEmployeeDataStorage: EmployeeDataStorage,
    @LocalServerPort private val serverPort: Int
) {
    private lateinit var employeeExampleClient: EmployeeExampleClient

    @BeforeAll
    fun createClient() {
        employeeExampleClient = EmployeeExampleClient.builder()
            .withBaseUrl("http://localhost:$serverPort")
            .build()
    }

    @Test
    fun `Assert that 'get' returns existing employee`() {
        testEmployeeDataStorage.getEmployees().forEach { expectedEmployee ->
            val actualEmployee = employeeExampleClient.get(expectedEmployee.id).block()

            requireNotNull(actualEmployee)

            assertThat(actualEmployee.id).isEqualTo(expectedEmployee.id)
            assertThat(actualEmployee.firstName).isEqualTo(expectedEmployee.firstName)
            assertThat(actualEmployee.lastName).isEqualTo(expectedEmployee.lastName)
            assertThat(actualEmployee.email).isEqualTo(expectedEmployee.email)
        }
    }

    @Test
    fun `Assert that 'getAll' returns list of employees`() {
        val actualEmployeeList = employeeExampleClient.getAll().collectList().block()
        val expectedEmployeeList = testEmployeeDataStorage.getEmployees()

        requireNotNull(actualEmployeeList)
        assertThat(actualEmployeeList.size).isEqualTo(expectedEmployeeList.size)

        actualEmployeeList.forEach { actualEmployee ->
            val expectedEmployee = expectedEmployeeList.single { it.id == actualEmployee.id }

            assertThat(actualEmployee.id).isEqualTo(expectedEmployee.id)
            assertThat(actualEmployee.firstName).isEqualTo(expectedEmployee.firstName)
            assertThat(actualEmployee.lastName).isEqualTo(expectedEmployee.lastName)
            assertThat(actualEmployee.email).isEqualTo(expectedEmployee.email)
        }
    }
}
