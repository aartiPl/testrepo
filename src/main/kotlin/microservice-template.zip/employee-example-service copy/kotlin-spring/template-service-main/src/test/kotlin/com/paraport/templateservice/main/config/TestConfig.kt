package com.paraport.templateservice.main.config

import com.paraport.templateservice.main.repository.EmployeeDataStorage
import com.paraport.templateservice.main.repository.TestEmployeeDataStorage
import org.springframework.boot.test.context.TestConfiguration
import org.springframework.context.annotation.Bean

@TestConfiguration
class TestConfig {

    @Bean
    fun testEmployeeDataStorage(): EmployeeDataStorage {
        return TestEmployeeDataStorage()
    }
}
