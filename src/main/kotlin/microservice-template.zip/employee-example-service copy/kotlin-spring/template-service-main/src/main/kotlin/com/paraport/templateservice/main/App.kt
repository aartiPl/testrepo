package com.paraport.templateservice.main

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
open class App {
    fun start(args: Array<String>) {
        runApplication<App>(*args)
    }

    companion object {
        @JvmStatic
        fun main(args: Array<String>) {
            App().start(args)
        }
    }
}
