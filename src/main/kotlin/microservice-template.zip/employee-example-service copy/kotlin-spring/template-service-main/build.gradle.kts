plugins {
    id("org.springframework.boot")
}

dependencies {
    implementation(project(":template-service-model"))

    implementation("org.springframework.boot:spring-boot-starter-webflux")
    implementation("com.fasterxml.jackson.module:jackson-module-kotlin")
    implementation("org.jetbrains.kotlin:kotlin-reflect")
    implementation("org.jetbrains.kotlin:kotlin-stdlib-jdk8")
    implementation("com.devskiller:jfairy:$jFairyVersion")

    testImplementation(project(":template-service-client"))
    testImplementation("org.springframework.boot:spring-boot-starter-test")
}
