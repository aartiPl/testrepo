rootProject.name = "kotlin-spring"

include("template-service-client")
include("template-service-model")
include("template-service-main")
