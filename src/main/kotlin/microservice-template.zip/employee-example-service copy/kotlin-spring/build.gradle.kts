group = "com.paraport.templateservice"
version = "1.0-SNAPSHOT"

plugins {
    kotlin("jvm") version kotlinVersion
    id("org.springframework.boot") version springVersion apply false
}

buildscript {
    repositories {
        mavenLocal()
        mavenCentral()
    }

    dependencies {
        classpath("com.paraport.gradlecommon:gradle-common:1.0.0-SNAPSHOT")
    }
}

apply(plugin = "com.paraport.gradle-common")

subprojects {
    apply(plugin = "org.jetbrains.kotlin.jvm")

    dependencies {
        implementation(platform(org.springframework.boot.gradle.plugin.SpringBootPlugin.BOM_COORDINATES))

        testImplementation("org.junit.jupiter:junit-jupiter:$jupiterVersion")
        testImplementation("com.willowtreeapps.assertk:assertk:$assertkVersion")
        testImplementation("nl.jqno.equalsverifier:equalsverifier:$equalsVerifierVersion")
    }
}

configure<com.paraport.gradlecommon.extension.CommonExtension> {
    testCoverage {
        excludeClasses = listOf(
            "com.paraport.templateservice.client.UsageExampleKt*",
            "com.paraport.templateservice.main.App*"
        )
        testLinesCoverage = 90
        testInstructionCoverage = 90
        testBranchCoverage = 90
    }
}
