#!/usr/bin/env kscript

@file:DependsOn("org.jetbrains.kotlin:kotlin-stdlib-jdk8:1.7.21")
@file:DependsOn("commons-io:commons-io:2.11.0")

import org.apache.commons.io.FileUtils
import org.apache.commons.io.filefilter.FileFilterUtils.nameFileFilter
import org.apache.commons.io.filefilter.FileFilterUtils.notFileFilter
import org.apache.commons.io.filefilter.FileFilterUtils.or
import java.io.File
import java.nio.file.Files
import java.nio.file.Path
import kotlin.io.path.createDirectories
import kotlin.io.path.exists
import kotlin.io.path.readBytes
import kotlin.io.path.writeBytes
import kotlin.system.exitProcess

val currentDir = Path.of(".").toRealPath()
val userHome = System.getProperty("user.home")
val pathSeparator = File.separator

fun validateServiceName(name: String): String {
    val validChars = "^[a-z]+[a-z0-9\\-]*$"
    val newName = name.trim()

    if (!validChars.toRegex().matches(name)) {
        println(
            "Invalid name: '$name'\nThe name should start with letters and contain only: lowercase " + "letters, digits, and dashes.\n"
        )
        exitProcess(1)
    }

    return newName
}

fun validateServiceType(serviceType: String): String {
    return when (serviceType.trim()) {
        "1" -> "kotlin-ktor"
        "2" -> "kotlin-spring"
        else -> {
            println("Invalid project type: '$serviceType'\nYou can choose only 1 or 2.")
            exitProcess(1)
        }
    }
}

fun validateOutputDir(outputDir: String, serviceName: String): Path {
    val newOutputDir = "$userHome$pathSeparator$outputDir"

    @Suppress("ForbiddenComment")
    //TODO: TemplateTreeTransformer with Builder to Utils?

    val path = Path.of(newOutputDir).resolve(serviceName)

    if (path.exists()) {
        println("Service '$serviceName' already exists. Please choose another name for project.")
        exitProcess(1)
    }

    return path.toAbsolutePath()
}

fun normalizePath(path: String): String = path.replace('\\', '/')

fun transformInputPath(relativeFile: String, serviceName: String, packageName: String): String {
    return when {
        relativeFile.startsWith("template-service") -> {
            //This is source code module
            relativeFile.replace("template-service", serviceName).replace("templateservice", packageName)
        }

        else -> {
            relativeFile
        }
    }
}

fun transformFileContent(
    content: ByteArray, relativeFile: String, serviceName: String, packageName: String, serviceType: String
): ByteArray {
    return when {
        relativeFile.endsWith("build.gradle.kts") -> {
            var text = String(content)

            text = text.replace("com.paraport.templateservice", "com.paraport.$packageName")
            text = text.replace(":template-service", ":$serviceName")

            text.toByteArray()
        }

        relativeFile.endsWith("settings.gradle.kts") -> {
            var text = String(content)

            text = text.replace(serviceType, serviceName)
            text = text.replace("template-service", serviceName)

            text.toByteArray()
        }

        relativeFile.endsWith(".kt") || relativeFile.endsWith(".kts") || relativeFile.endsWith("logback.xml") || relativeFile.endsWith(
            "logback-test.xml"
        ) -> {
            var text = String(content)

            text = text.replace("com.paraport.templateservice", "com.paraport.$packageName")

            text.toByteArray()
        }

        else -> {
            content
        }
    }
}

println("This is micro-service generator")
println("Please provide micro-service details to create skeleton of the project")
println()

println("Service name (lower-case letters with dashes for multi part name)")
val serviceName = validateServiceName(readln())

println("Service type:\n1) kotlin-ktor\n2) kotlin-spring")
val serviceType = validateServiceType(readln())

println("Path relative to user home to create a new service [$userHome$pathSeparator]:")
val serviceDir = validateOutputDir(readln(), serviceName)

val inputDir = currentDir.resolve(serviceType).toRealPath()
val packageName = serviceName.replace("-", "")

println("Generator settings:")
println("Name:          $serviceName")
println("Package name:  $packageName")
println("Service type:  $serviceType")
println("Current dir:   $currentDir")
println("Input dir:     $inputDir")
println("Service dir:   $serviceDir")

println("Generating...")

//Create directory structure
Files.createDirectories(serviceDir)

val skippedDirs = notFileFilter(or(nameFileFilter(".gradle"), nameFileFilter("build"), nameFileFilter(".idea")))
val skippedFiles = notFileFilter(or(nameFileFilter("detekt.yml")))

val filesToCopy =
    FileUtils.listFiles(inputDir.toFile(), skippedFiles, skippedDirs).map { normalizePath(it.canonicalPath) }

filesToCopy.forEach {
    val relativeFile = it.substringAfter(normalizePath(inputDir.toString())).substring(1)
    print("Processing: $relativeFile --> ")

    val inputFile = Path.of(it)

    //1. Transform output path
    val outputFile = serviceDir.resolve(transformInputPath(relativeFile, serviceName, packageName))
    println(outputFile)


    //2. Transform the file content
    val content =
        transformFileContent(inputFile.readBytes(), relativeFile, serviceName, packageName, serviceType)

    //3. Save the file
    outputFile.parent.createDirectories()
    outputFile.writeBytes(content)
}
