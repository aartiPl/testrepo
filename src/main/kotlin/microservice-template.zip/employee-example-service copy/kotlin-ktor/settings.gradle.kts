rootProject.name = "kotlin-ktor"
include("template-service-client")
include("template-service-model")
include("template-service-main")
