group = "com.paraport.templateservice"
version = "1.0-SNAPSHOT"

plugins {
    kotlin("jvm") version kotlinVersion
}

apply(plugin = "com.paraport.gradle-common")

buildscript {
    repositories {
        mavenLocal()
        mavenCentral()
    }

    dependencies {
        classpath("com.paraport.gradlecommon:gradle-common:1.0.0-SNAPSHOT")
    }
}

subprojects {
    apply(plugin = "org.jetbrains.kotlin.jvm")

    dependencies {
        testImplementation("org.junit.jupiter:junit-jupiter:$jupiterVersion")
        testImplementation("com.willowtreeapps.assertk:assertk:$assertkVersion")
        testImplementation("nl.jqno.equalsverifier:equalsverifier:$equalsVerifierVersion")
    }
}

configure<com.paraport.gradlecommon.extension.CommonExtension> {
    testCoverage {
        excludeClasses = listOf(
            "com.paraport.templateservice.main.ModuleKt*",
            "com.paraport.templateservice.main.App*",
            "com.paraport.templateservice.main.Server*"
        )
        testLinesCoverage = 90
        testInstructionCoverage = 90
        testBranchCoverage = 90
    }
}
