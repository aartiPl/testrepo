dependencies {
    implementation(project(":template-service-model"))

    implementation("io.ktor:ktor-client-core:$ktorVersion")
    implementation("io.ktor:ktor-client-cio:$ktorVersion")
    implementation("io.ktor:ktor-client-content-negotiation:$ktorVersion")
    implementation("io.ktor:ktor-serialization-jackson:$ktorVersion")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:$coroutinesCoreVersion")
    implementation("ch.qos.logback:logback-classic:$logbackVersion")

    testImplementation("com.github.tomakehurst:wiremock-jre8:$wireMockVersion")
}
