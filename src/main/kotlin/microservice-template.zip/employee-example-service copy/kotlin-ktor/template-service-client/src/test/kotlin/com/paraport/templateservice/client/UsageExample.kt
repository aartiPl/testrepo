package com.paraport.templateservice.client

import io.ktor.client.HttpClient
import io.ktor.client.engine.cio.CIO
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.serialization.jackson.jackson
import kotlinx.coroutines.runBlocking
import org.slf4j.Logger
import org.slf4j.LoggerFactory

val logger: Logger = LoggerFactory.getLogger("com.paraport.templateservice.client")

private fun createHttpClient(): HttpClient = HttpClient(CIO) {
    install(ContentNegotiation) {
        jackson()
    }
}

fun main() = runBlocking {
    createHttpClient().use { httpClient ->
        val employeeExampleClient = EmployeeExampleClient.builder()
            .withHttpClient(httpClient)
            .withBaseUrl("http://localhost:8080")
            .build()

        logger.info("Employee #5:   {}", employeeExampleClient.get(5))
        logger.info("All employees: {}", employeeExampleClient.getAll())
    }
}
