package com.paraport.templateservice.client

import com.paraport.templateservice.model.Employee
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.request.get
import io.ktor.http.ContentType
import io.ktor.http.contentType
import io.ktor.http.path
import java.net.URL

class EmployeeExampleClient internal constructor(
    private val client: HttpClient,
    private val baseUrl: URL
) {
    suspend fun getAll(): List<Employee> {
        val response = client.get(baseUrl) {
            contentType(ContentType.Application.Json)
            url {
                path(employeePath)
            }
        }

        return response.body()
    }

    suspend fun get(id: Int): Employee {
        val response = client.get(baseUrl) {
            contentType(ContentType.Application.Json)
            url {
                path("$employeePath/$id")
            }
        }

        return response.body()
    }

    companion object {
        private const val employeePath: String = "employees"

        @JvmStatic
        fun builder() = EmployeeExampleClientBuilder()
    }
}
