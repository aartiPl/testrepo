package com.paraport.templateservice.client

import io.ktor.client.HttpClient
import java.net.URL

@Suppress("unused")
class EmployeeExampleClientBuilder {
    private var httpClient: HttpClient? = null
    private var baseUrl: URL? = null

    fun withHttpClient(httpClient: HttpClient) = apply { this.httpClient = httpClient }

    fun withBaseUrl(baseUrl: URL) = apply { this.baseUrl = baseUrl }

    fun withBaseUrl(baseUrl: String) = apply { this.baseUrl = URL(baseUrl) }

    fun build(): EmployeeExampleClient {
        requireNotNull(httpClient)
        requireNotNull(baseUrl)

        return EmployeeExampleClient(httpClient!!, baseUrl!!)
    }
}
