package com.paraport.templateservice.model

import assertk.all
import assertk.assertThat
import assertk.assertions.endsWith
import assertk.assertions.startsWith
import nl.jqno.equalsverifier.EqualsVerifier
import org.junit.jupiter.api.Test

class EmployeeTest {

    @Test
    fun `Assert that Equals and HashCode works correctly for Employee`() {
        EqualsVerifier.forClass(Employee::class.java)
            .usingGetClass()
            .verify()
    }

    @Test
    fun `Assert that toString() works correctly`() {
        assertThat(
            Employee(0, "piperdawson@yahoo.com", "Piper", "Dawson").toString()
        ).all {
            startsWith("Employee(id=0")
            endsWith(", email=piperdawson@yahoo.com, firstName=Piper, lastName=Dawson)")
        }

        assertThat(
            Employee(1, "evalawrence@gmail.com", "Eva", "Dawson").toString()
        ).all {
            startsWith("Employee(id=1")
            endsWith(", email=evalawrence@gmail.com, firstName=Eva, lastName=Dawson)")
        }
    }
}
