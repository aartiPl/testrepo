package com.paraport.templateservice.model

data class Employee(
    val id: Int,
    val email: String,
    val firstName: String,
    val lastName: String
)
