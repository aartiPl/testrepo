package com.paraport.templateservice.main

import org.koin.core.context.startKoin

@Suppress("unused")
class App(private val args: Array<String>) {
    private val koinApp = startKoin {
        modules(commonModule, productionModule)
    }

    fun start(wait: Boolean = true) {
        koinApp.koin.get<Server>().start(wait)
    }

    fun stop() {
        koinApp.koin.get<Server>().stop()
    }

    companion object {
        @JvmStatic
        fun main(args: Array<String>) {
            App(args).start()
        }
    }
}
