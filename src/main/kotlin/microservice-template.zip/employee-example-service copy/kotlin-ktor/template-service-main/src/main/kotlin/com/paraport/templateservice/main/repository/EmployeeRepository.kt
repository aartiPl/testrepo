package com.paraport.templateservice.main.repository

import com.paraport.templateservice.model.Employee
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class EmployeeRepository(private val dataStorage: EmployeeDataStorage) {

    suspend fun getAll(): List<Employee> = withContext(Dispatchers.IO) {
        dataStorage.getEmployees()
    }

    suspend fun get(id: Int): Employee = withContext(Dispatchers.IO) {
        dataStorage.getEmployees().single { it.id == id }
    }
}
