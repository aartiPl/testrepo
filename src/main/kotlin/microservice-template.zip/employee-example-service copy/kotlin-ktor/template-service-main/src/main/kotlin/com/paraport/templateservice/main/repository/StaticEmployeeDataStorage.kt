package com.paraport.templateservice.main.repository

import com.devskiller.jfairy.Fairy
import com.paraport.templateservice.model.Employee

class StaticEmployeeDataStorage : EmployeeDataStorage {

    override fun getEmployees() = employeeList

    companion object {
        private val employeeList: MutableList<Employee> = mutableListOf()

        init {
            val fairy = Fairy.create()
            @Suppress("MagicNumber")
            for (i in 0 until (100..200).random()) {
                val person = fairy.person()
                employeeList.add(Employee(i, person.email, person.firstName, person.lastName))
            }
        }
    }
}
