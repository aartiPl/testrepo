package com.paraport.templateservice.main.repository

import com.paraport.templateservice.model.Employee

interface EmployeeDataStorage {
    fun getEmployees(): List<Employee>
}
