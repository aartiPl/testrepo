package com.paraport.templateservice.main

import com.paraport.templateservice.main.repository.EmployeeDataStorage
import com.paraport.templateservice.main.repository.TestEmployeeDataStorage
import io.ktor.client.HttpClient
import io.ktor.client.engine.cio.CIO
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.serialization.jackson.jackson
import org.koin.dsl.module

val testModule = module {
    single<EmployeeDataStorage> { TestEmployeeDataStorage() }
    single { createHttpClient() }
}

private fun createHttpClient() = HttpClient(CIO) {
    install(ContentNegotiation) {
        jackson()
    }
}
