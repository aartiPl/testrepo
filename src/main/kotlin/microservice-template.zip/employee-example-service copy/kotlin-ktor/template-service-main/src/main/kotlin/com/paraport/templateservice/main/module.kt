package com.paraport.templateservice.main

import com.paraport.templateservice.main.controller.Router
import com.paraport.templateservice.main.repository.EmployeeDataStorage
import com.paraport.templateservice.main.repository.EmployeeRepository
import com.paraport.templateservice.main.repository.StaticEmployeeDataStorage
import com.paraport.templateservice.main.service.EmployeeService
import org.koin.dsl.module

val commonModule = module {
    single { Server(get()) }
    single { Router(get()) }
    single { EmployeeRepository(get()) }
    single { EmployeeService(get()) }
}

val productionModule = module {
    single<EmployeeDataStorage> { StaticEmployeeDataStorage() }
}
