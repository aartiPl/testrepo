package com.paraport.templateservice.main.controller

import com.paraport.templateservice.main.service.EmployeeService
import io.ktor.server.application.Application
import io.ktor.server.routing.routing

class Router(private val employeeService: EmployeeService) {
    fun configure(application: Application) {
        application.routing {
            employeeRoutes(employeeService)
        }
    }
}
