package com.paraport.templateservice.main

import com.paraport.templateservice.main.controller.Router
import io.ktor.serialization.jackson.jackson
import io.ktor.server.application.install
import io.ktor.server.engine.embeddedServer
import io.ktor.server.netty.Netty
import io.ktor.server.plugins.contentnegotiation.ContentNegotiation

class Server(private val router: Router) {
    private val ktorServer = embeddedServer(Netty, port = 8080, host = "localhost") {
        install(ContentNegotiation) {
            jackson()
        }

        router.configure(this)
    }

    fun start(wait: Boolean = true) {
        ktorServer.start(wait = wait)
    }

    fun stop() {
        ktorServer.stop()
    }
}
