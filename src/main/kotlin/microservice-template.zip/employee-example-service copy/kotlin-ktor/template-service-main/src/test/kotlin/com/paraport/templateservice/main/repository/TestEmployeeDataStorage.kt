package com.paraport.templateservice.main.repository

import com.paraport.templateservice.model.Employee

class TestEmployeeDataStorage : EmployeeDataStorage {

    override fun getEmployees() = employeeList

    companion object {
        @JvmStatic
        private val employeeList: MutableList<Employee> = mutableListOf(
            Employee(0, "piperdawson@yahoo.com", "Piper", "Dawson"),
            Employee(1, "evalawrence@gmail.com", "Eva", "Dawson"),
            Employee(2, "shepherd@mail.com", "London", "Shepherd"),
            Employee(3, "connorgrimes@gmail.com", "Connor", "Grimes"),
            Employee(4, "ramirez@mail.com", "Avery", "Ramirez")
        )
    }
}
