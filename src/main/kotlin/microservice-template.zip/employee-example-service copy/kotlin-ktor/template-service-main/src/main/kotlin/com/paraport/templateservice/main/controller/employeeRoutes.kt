package com.paraport.templateservice.main.controller

import com.paraport.templateservice.main.service.EmployeeService
import io.ktor.server.application.call
import io.ktor.server.response.respond
import io.ktor.server.routing.Route
import io.ktor.server.routing.get
import io.ktor.server.util.getOrFail

fun Route.employeeRoutes(employeeService: EmployeeService) {
    get("/employees") {
        call.respond(employeeService.getAll())
    }
    get("/employees/{id}") {
        call.respond(employeeService.get(call.parameters.getOrFail<Int>("id").toInt()))
    }
}
