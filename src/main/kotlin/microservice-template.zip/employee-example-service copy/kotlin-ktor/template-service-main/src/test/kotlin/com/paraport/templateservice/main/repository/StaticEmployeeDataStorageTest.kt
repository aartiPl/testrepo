package com.paraport.templateservice.main.repository

import assertk.all
import assertk.assertThat
import assertk.assertions.isGreaterThanOrEqualTo
import assertk.assertions.isLessThanOrEqualTo
import assertk.assertions.isNotEmpty
import assertk.assertions.isNotNull
import org.junit.jupiter.api.Test

class StaticEmployeeDataStorageTest {

    @Test
    fun `Test that static employee data storage initiated correctly`() {
        val dataStorage = StaticEmployeeDataStorage()

        assertThat(dataStorage.getEmployees()).all {
            isNotNull()
            isNotEmpty()

        }

        assertThat(dataStorage.getEmployees().size).all {
            isGreaterThanOrEqualTo(100)
            isLessThanOrEqualTo(200)
        }
    }
}
