package com.paraport.templateservice.main.controller

import assertk.assertThat
import assertk.assertions.isEqualTo
import com.paraport.templateservice.main.TestApp
import com.paraport.templateservice.main.repository.EmployeeDataStorage
import com.paraport.templateservice.client.EmployeeExampleClient
import io.ktor.client.HttpClient
import kotlinx.coroutines.runBlocking
import org.junit.jupiter.api.AfterAll
import org.junit.jupiter.api.BeforeAll
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.TestInstance

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class EmployeeControllerTest {
    private val testApp = TestApp()
    private val httpClient: HttpClient = testApp.appDependencies.get()
    private val employeeStorage: EmployeeDataStorage = testApp.appDependencies.get()

    private val employeeExampleClient = EmployeeExampleClient.builder()
        .withHttpClient(httpClient)
        .withBaseUrl("http://localhost:8080")
        .build()

    @BeforeAll
    fun startService() {
        testApp.start()
    }

    @AfterAll
    fun stopService() {
        testApp.stop()
    }

    @Test
    fun `Assert that 'get' returns existing employee`() = runBlocking {
        employeeStorage.getEmployees().forEach { expectedEmployee ->
            val actualEmployee = employeeExampleClient.get(expectedEmployee.id)

            assertThat(actualEmployee.id).isEqualTo(expectedEmployee.id)
            assertThat(actualEmployee.firstName).isEqualTo(expectedEmployee.firstName)
            assertThat(actualEmployee.lastName).isEqualTo(expectedEmployee.lastName)
            assertThat(actualEmployee.email).isEqualTo(expectedEmployee.email)
        }
    }

    @Test
    fun `Assert that 'getAll' returns list of employees`() = runBlocking {
        val actualEmployeeList = employeeExampleClient.getAll()
        val expectedEmployeeList = employeeStorage.getEmployees()

        assertThat(actualEmployeeList.size).isEqualTo(expectedEmployeeList.size)

        actualEmployeeList.forEach { actualEmployee ->
            val expectedEmployee = expectedEmployeeList.single { it.id == actualEmployee.id }

            assertThat(actualEmployee.id).isEqualTo(expectedEmployee.id)
            assertThat(actualEmployee.firstName).isEqualTo(expectedEmployee.firstName)
            assertThat(actualEmployee.lastName).isEqualTo(expectedEmployee.lastName)
            assertThat(actualEmployee.email).isEqualTo(expectedEmployee.email)
        }
    }
}
