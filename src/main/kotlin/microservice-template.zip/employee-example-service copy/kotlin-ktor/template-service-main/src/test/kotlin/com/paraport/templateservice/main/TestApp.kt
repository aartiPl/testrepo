package com.paraport.templateservice.main

import org.koin.core.Koin
import org.koin.core.context.startKoin

class TestApp {
    private val koinApp = startKoin {
        modules(commonModule, testModule)
    }

    val appDependencies: Koin
        get() = koinApp.koin

    fun start(wait: Boolean = false) {
        koinApp.koin.get<Server>().start(wait)
    }

    fun stop() {
        koinApp.koin.get<Server>().stop()
    }
}
