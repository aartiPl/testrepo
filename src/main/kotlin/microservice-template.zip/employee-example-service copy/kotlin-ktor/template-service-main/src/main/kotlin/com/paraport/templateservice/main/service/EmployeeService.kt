package com.paraport.templateservice.main.service

import com.paraport.templateservice.main.repository.EmployeeRepository
import com.paraport.templateservice.model.Employee

class EmployeeService(private val employeeRepository: EmployeeRepository) {
    suspend fun getAll(): List<Employee> {
        return employeeRepository.getAll()
    }

    suspend fun get(id: Int): Employee {
        return employeeRepository.get(id)
    }
}
